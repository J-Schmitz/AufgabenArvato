package aufgabe1;

public class SortMain {
	
	//Nur eine Klasse f�r Zwischentests 
	public static void main (String [] args) {
		
		Sort wordSort = new Sort ("List1.txt", "List2.txt");
		wordSort.sortWords();
	
		
		
	}	

}
